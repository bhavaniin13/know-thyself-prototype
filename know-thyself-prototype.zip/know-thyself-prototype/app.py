"""Know Thyself - prototype dashboard (Streamlit).
Run:  streamlit run app.py
"""
import streamlit as st
import pandas as pd
import logic

st.set_page_config(page_title="Know Thyself", page_icon="🧠", layout="centered")

# ------------------------------------------------------------ session state
if "df" not in st.session_state:
    st.session_state.df = logic.generate_sample_data()
if "enabled" not in st.session_state:
    st.session_state.enabled = {k: True for k in logic.SOURCES}

enabled = st.session_state.enabled
df = st.session_state.df

# ------------------------------------------------------------------ header
st.title("🧠 Know Thyself")
st.caption("Your data. Your intelligence. Sample data is used in this prototype.")

with st.sidebar:
    st.header("Data")
    st.write(f"Rows loaded: **{len(df)}**")
    uploaded = st.file_uploader("Upload your own CSV", type="csv")
    st.caption("Columns: date, sleep_hours, steps, screen_hours, mood (1-5)")
    if uploaded is not None:
        try:
            st.session_state.df = logic.load_data(uploaded)
            st.success("Data loaded.")
            df = st.session_state.df
        except Exception as e:  # show a friendly error instead of crashing
            st.error(f"Could not read file: {e}")
    if st.button("Reset to sample data"):
        st.session_state.df = logic.generate_sample_data()
        st.rerun()
    st.info("Lifestyle guidance only. Not medical advice.")

if df.empty:
    st.warning("No data available. Upload a CSV or reset to sample data in the sidebar.")
    st.stop()

scored = logic.add_scores(df, enabled)
active_cols = [c for k, c in logic.SOURCES.items() if enabled.get(k, True)]
chart_df = scored.set_index("date")

tab_time, tab_ins, tab_nudge, tab_whatif, tab_priv = st.tabs(
    ["Timeline", "AI Insights", "Nudge", "What-If", "Privacy"]
)

# ---------------------------------------------------------------- timeline
with tab_time:
    today = scored.iloc[-1]
    prev = scored.iloc[-2] if len(scored) > 1 else today
    c1, c2, c3 = st.columns(3)
    c1.metric("Vibe Score", f"{int(today['vibe_score'])}/100",
              int(today["vibe_score"] - prev["vibe_score"]))
    if enabled.get("sleep", True):
        c2.metric("Sleep", f"{today['sleep_hours']:.1f} h")
    if enabled.get("steps", True):
        c3.metric("Steps", f"{int(today['steps']):,}")
    if logic.burnout_alert(df):
        st.warning("Burnout warning: short sleep, long screen time and low mood over the last 3 days.")
    st.subheader("Vibe Score over time")
    st.line_chart(chart_df["vibe_score"])
    if active_cols:
        st.subheader("Your days, all sources")
        st.dataframe(df[["date"] + active_cols], use_container_width=True, hide_index=True)
        if enabled.get("sleep", True) or enabled.get("screen", True):
            hours_cols = [c for c in ("sleep_hours", "screen_hours") if c in active_cols]
            st.line_chart(chart_df[hours_cols])
        if enabled.get("steps", True):
            st.bar_chart(chart_df["steps"])

# ---------------------------------------------------------------- insights
with tab_ins:
    st.subheader("Patterns found in your data")
    insights = logic.get_insights(df, enabled)
    if not insights:
        st.info("Need at least 5 days of data and 2 enabled sources to find patterns.")
    for item in insights:
        st.markdown(f"**{item['title']}**")
        st.write(item["text"])
        st.caption(f"Strength: {item['strength']} | Confidence: {item['confidence']}")
        st.divider()

# ------------------------------------------------------------------- nudge
with tab_nudge:
    st.subheader("Today's nudge")
    n = logic.get_nudge(df, enabled)
    st.success(n["nudge"])
    if n["why"]:
        st.caption("Why: " + n["why"])
    st.subheader("Suggested routine")
    for step in logic.suggest_routine(df):
        st.write("- " + step)

# ------------------------------------------------------------------ what-if
with tab_whatif:
    st.subheader("What-If Simulator")
    st.write("Test a habit change on your own data before you try it.")
    extra = st.slider("If I sleep this many hours more per night", 0.0, 2.0, 1.0, 0.5)
    res = logic.what_if_sleep(df, extra)
    if res["ok"]:
        a, b = st.columns(2)
        a.metric("Average mood now", f"{res['baseline']:.2f} / 5")
        b.metric("Predicted mood", f"{res['predicted']:.2f} / 5", f"{res['delta']:+.2f}")
        st.caption("Simple estimate from your own data. Not medical advice.")
    else:
        st.info(res["message"])

# ----------------------------------------------------------------- privacy
with tab_priv:
    st.subheader("Privacy Vault: you own your data")
    st.write("Choose which data sources the app may use. Everything below updates instantly.")
    for key, label in [("sleep", "Sleep data"), ("steps", "Steps data"),
                       ("screen", "Screen time data"), ("mood", "Mood data")]:
        st.session_state.enabled[key] = st.toggle(label, value=enabled.get(key, True), key="tg_" + key)
    st.caption("In this prototype all data stays in your browser session. Nothing is sent anywhere.")
    st.download_button("Export my data (CSV)", df.to_csv(index=False).encode("utf-8"),
                       file_name="my_data.csv", mime="text/csv")
    if st.button("Delete my data"):
        st.session_state.df = df.iloc[0:0]
        st.rerun()
