# Know Thyself - Prototype

**Team COSMIX** | wHACKiest 2026 Online Ideathon | Track: Know Thyself

Know Thyself turns scattered phone, watch and journal data (sleep, steps, screen time, mood)
into a personal digital twin that explains your patterns and nudges you to improve them,
with privacy and data ownership built in.

This repo is a **working prototype on sample data**, built with Python and Streamlit so it
runs in one command. The full design in our PPT uses React, FastAPI, PostgreSQL and an LLM;
this prototype shows the core idea end to end.

## Features in this prototype
| Feature | Where |
|---|---|
| Personal timeline + Vibe Score (0-100) | Timeline tab |
| AI life-pattern detection (correlations with confidence) | AI Insights tab |
| One daily nudge + suggested routine (explainable rules) | Nudge tab |
| What-If Simulator (mood vs sleep, fitted on your own data) | What-If tab |
| Privacy Vault: per-source consent toggles, export, delete | Privacy tab |
| Burnout warning (3-day pattern) | Timeline tab |
| Upload your own CSV | Sidebar |

## Run it
```bash
pip install -r requirements.txt
streamlit run app.py
```
Run the logic tests: `python test_logic.py`

## CSV format
`date, sleep_hours, steps, screen_hours, mood` (mood is 1-5). See `data/sample_data.csv`.

## Privacy
Data stays in the browser session. Turning a source off removes it from the score,
insights and nudges immediately. Export and delete are one click.

## Next steps
Wearable sync (Google Fit / Apple Health), LLM-written explanations, encrypted PostgreSQL storage,
React frontend.

*Lifestyle guidance only. Not medical advice.*
