import logic

def test_all():
    df = logic.generate_sample_data()
    assert len(df) == 14 and list(df.columns) == logic.REQUIRED_COLUMNS
    s = logic.add_scores(df)["vibe_score"]
    assert s.between(0, 100).all()
    # turning sources off must keep the score on a 0-100 scale
    only_sleep = {"sleep": True, "steps": False, "screen": False, "mood": False}
    assert 0 <= logic.vibe_score(df.iloc[0], only_sleep) <= 100
    assert logic.vibe_score(df.iloc[0], {k: False for k in logic.SOURCES}) == 0
    assert len(logic.get_insights(df)) == 3
    assert logic.get_insights(df, only_sleep) == []          # needs 2 sources
    assert logic.get_insights(df.head(3)) == []              # needs 5 days
    assert "slept" in logic.get_nudge(df)["nudge"]           # demo day is a poor night
    assert logic.what_if_sleep(df, 1.0)["ok"]
    assert not logic.what_if_sleep(df.head(2), 1.0)["ok"]
    assert len(logic.suggest_routine(df)) == 3
    assert logic.get_nudge(df.iloc[0:0])["why"] == ""
    print("all tests passed")

if __name__ == "__main__":
    test_all()
