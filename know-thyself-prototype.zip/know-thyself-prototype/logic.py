"""Know Thyself - core logic (pure pandas/numpy, no UI).

Everything here works on a DataFrame with the columns:
date, sleep_hours, steps, screen_hours, mood  (mood is 1-5)
"""
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

SOURCES = {
    "sleep": "sleep_hours",
    "steps": "steps",
    "screen": "screen_hours",
    "mood": "mood",
}
LABELS = {
    "sleep_hours": "sleep",
    "steps": "steps",
    "screen_hours": "screen time",
    "mood": "mood",
}
REQUIRED_COLUMNS = ["date", "sleep_hours", "steps", "screen_hours", "mood"]


# ---------------------------------------------------------------- data
def generate_sample_data(days: int = 14, seed: int = 7) -> pd.DataFrame:
    """Realistic fake data: short sleep + long screen time -> lower mood."""
    rng = np.random.default_rng(seed)
    dates = pd.date_range(end=pd.Timestamp.today().normalize(), periods=days)
    screen = np.clip(rng.normal(4.8, 1.6, days), 1.5, 9.0)
    sleep = np.clip(7.4 - 0.35 * (screen - 4.8) + rng.normal(0, 0.7, days), 4.5, 9.0)
    steps = np.clip(rng.normal(6500, 2500, days), 1500, 14000)
    mood = np.clip(
        3.0 + 0.45 * (sleep - 6.8) + 0.00008 * (steps - 6500)
        - 0.12 * (screen - 4.8) + rng.normal(0, 0.35, days),
        1, 5,
    )
    df = pd.DataFrame({
        "date": dates,
        "sleep_hours": sleep.round(1),
        "steps": steps.round(-2).astype(int),
        "screen_hours": screen.round(1),
        "mood": mood.round(1),
    })
    # make the latest day a poor night so the demo shows a nudge
    df.loc[df.index[-1], ["sleep_hours", "screen_hours", "mood"]] = [5.6, 6.4, 2.4]
    return df


def load_data(source) -> pd.DataFrame:
    """Read a CSV path or file-like object and validate it."""
    df = pd.read_csv(source)
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError("Missing columns: " + ", ".join(missing))
    df = df[REQUIRED_COLUMNS].copy()
    df["date"] = pd.to_datetime(df["date"])
    for c in REQUIRED_COLUMNS[1:]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    return df.dropna().sort_values("date").reset_index(drop=True)


# ---------------------------------------------------------- vibe score
def vibe_score(row, enabled=None) -> int:
    """0-100 wellness score. Only enabled data sources count; weights are
    re-balanced so the score stays on a 0-100 scale."""
    enabled = enabled or {k: True for k in SOURCES}
    parts = {
        "sleep": (min(row["sleep_hours"] / 8.0, 1.0), 40),
        "steps": (min(row["steps"] / 10000.0, 1.0), 25),
        "screen": (1.0 - min(row["screen_hours"] / 8.0, 1.0), 20),
        "mood": (min(max((row["mood"] - 1) / 4.0, 0.0), 1.0), 15),
    }
    used = [(v, w) for k, (v, w) in parts.items() if enabled.get(k, True)]
    if not used:
        return 0
    total_w = sum(w for _, w in used)
    return int(round(sum(v * w for v, w in used) / total_w * 100))


def add_scores(df: pd.DataFrame, enabled=None) -> pd.DataFrame:
    out = df.copy()
    out["vibe_score"] = out.apply(lambda r: vibe_score(r, enabled), axis=1)
    return out


# ------------------------------------------------------------- insights
def _confidence(r: float, n: int) -> str:
    if n < 7:
        return "low (needs more days)"
    r = abs(r)
    if r >= 0.6:
        return "high"
    if r >= 0.35:
        return "medium"
    return "low"


def _sentence(a: str, b: str, r: float) -> str:
    direction = "go up together" if r > 0 else "move in opposite directions"
    return f"Your {LABELS[a]} and {LABELS[b]} tend to {direction}."


def get_insights(df: pd.DataFrame, enabled=None, top_n: int = 3, min_days: int = 5):
    """Find the strongest pairwise correlations between enabled sources."""
    enabled = enabled or {k: True for k in SOURCES}
    cols = [c for k, c in SOURCES.items() if enabled.get(k, True)]
    if len(df) < min_days or len(cols) < 2:
        return []
    corr = df[cols].corr()
    pairs = []
    for i, a in enumerate(cols):
        for b in cols[i + 1:]:
            r = corr.loc[a, b]
            if pd.notna(r):
                pairs.append((a, b, float(r)))
    pairs.sort(key=lambda t: abs(t[2]), reverse=True)
    return [
        {"title": f"{LABELS[a].capitalize()} and {LABELS[b]}",
         "text": _sentence(a, b, r),
         "strength": round(abs(r), 2),
         "confidence": _confidence(r, len(df))}
        for a, b, r in pairs[:top_n]
    ]


# ---------------------------------------------------------------- nudge
def get_nudge(df: pd.DataFrame, enabled=None) -> dict:
    """One daily nudge from simple, explainable rules on the latest day."""
    enabled = enabled or {k: True for k in SOURCES}
    if df.empty:
        return {"nudge": "No data yet. Upload or generate data to get a nudge.", "why": ""}
    last = df.iloc[-1]
    if enabled.get("sleep", True) and last["sleep_hours"] < 6.5:
        return {"nudge": f"You slept {last['sleep_hours']:.1f} h. Try screens off 30 minutes earlier tonight.",
                "why": "Sleep was below 6.5 hours."}
    if enabled.get("screen", True) and last["screen_hours"] > 6:
        return {"nudge": f"Screen time was {last['screen_hours']:.1f} h. Take a 10-minute break outside.",
                "why": "Screen time was above 6 hours."}
    if enabled.get("steps", True) and last["steps"] < 4000:
        return {"nudge": f"Only {int(last['steps'])} steps so far. A short walk could lift your energy.",
                "why": "Steps were below 4,000."}
    return {"nudge": "Nice balance today. Keep the same routine tomorrow.",
            "why": "No warning signs in the latest day."}


def burnout_alert(df: pd.DataFrame) -> bool:
    """Warning signs over the last 3 days: short sleep, long screens, low mood."""
    if len(df) < 3:
        return False
    last3 = df.tail(3)
    return bool(last3["sleep_hours"].mean() < 6.0
                and last3["screen_hours"].mean() > 5.5
                and last3["mood"].mean() < 3.0)


def suggest_routine(df: pd.DataFrame) -> list:
    """Tiny rule-based routine; wake time fixed at 7:00 for the demo."""
    avg_sleep = float(df["sleep_hours"].tail(7).mean()) if not df.empty else 7.0
    target = 8.0 if avg_sleep < 7 else round(avg_sleep, 1)
    wake = datetime(2000, 1, 2, 7, 0)
    bed = wake - timedelta(hours=target)
    wind = bed - timedelta(minutes=30)
    fmt = lambda d: d.strftime("%I:%M %p").lstrip("0").lower()
    return [
        f"{fmt(wind)} - wind down, screens off",
        f"{fmt(bed)} - lights out (target {target:g} h sleep)",
        f"{fmt(wake)} - wake up and take a 10-minute walk",
    ]


# --------------------------------------------------------------- what-if
def what_if_sleep(df: pd.DataFrame, extra_hours: float) -> dict:
    """Estimate mood change if sleep changes, from a simple straight-line fit
    on the user's own data. Lifestyle estimate only, not medical advice."""
    if len(df) < 5 or df["sleep_hours"].nunique() < 2:
        return {"ok": False, "message": "Need at least 5 days of varied sleep data."}
    slope, _ = np.polyfit(df["sleep_hours"], df["mood"], 1)
    base = float(df["mood"].tail(7).mean())
    new = float(np.clip(base + slope * extra_hours, 1, 5))
    return {"ok": True, "slope": float(slope), "baseline": base, "predicted": new,
            "delta": new - base}
